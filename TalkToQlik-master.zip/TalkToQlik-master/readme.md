# w0wTimeline

Its a timeline that lets you have 2 dimensions. The task start and end dates are measures.

* DIM 1 - PROJECT NAME
* DIM 2 - DATE TYPE - E.G Plan, Actual, Baseline.
* Dim 3 - TASK NAME

* Measure 1 - Start Date
* Measure 2 - End Date
* Measure 3 - Color Code.. currently can be block_blue, block_green, block_amber, block_red.
