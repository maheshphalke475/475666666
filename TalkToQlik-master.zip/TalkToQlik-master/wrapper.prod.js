var extPath = "//assets.webofwork.com/extensions/talk-to-qlik/auto/";
define([extPath + "bundle.js", "css!" + extPath + "style.css"], function (b) { return b; });